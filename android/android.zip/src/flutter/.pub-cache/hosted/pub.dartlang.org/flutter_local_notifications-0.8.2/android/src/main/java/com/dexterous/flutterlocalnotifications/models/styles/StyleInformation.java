package com.dexterous.flutterlocalnotifications.models.styles;

public abstract class StyleInformation {
}
